#!/bin/bash

LUKS_DEV="/dev/disk/by-partlabel/scratch"
MOUNT_POINT="/run/kata-containers"
MAPPER_NAME="scratch"
KEY_PATH=/run/lukspw.bin

# Log the start of the operation
echo "Starting ephemeral LUKS setup for $LUKS_DEV..."

# 0. generate a random file
echo "Generating random key in $KEY_PATH"
dd if=/dev/urandom of=$KEY_PATH bs=64 count=1

# 1. Create
echo "Formatting $LUKS_DEV as LUKS with random key"
if ! cryptsetup luksFormat --type luks2 --cipher aes-xts-plain64 --key-size 512 --hash sha256 --batch-mode "$LUKS_DEV" --key-file $KEY_PATH; then
    echo "ERROR: Failed to luksFormat $LUKS_DEV. Aborting."
    exit 1
fi

# 2. Open the newly formatted LUKS device
echo "Opening LUKS device $LUKS_DEV as /dev/mapper/$MAPPER_NAME..."
if ! cryptsetup luksOpen "$LUKS_DEV" "$MAPPER_NAME" --key-file $KEY_PATH; then
    echo "ERROR: Failed to luksOpen $LUKS_DEV. Aborting."
    exit 1
fi

# 3. Create an ext4 filesystem inside the decrypted volume
echo "Creating ext4 filesystem on /dev/mapper/$MAPPER_NAME..."
if ! mkfs.ext4 -F "/dev/mapper/$MAPPER_NAME"; then
    echo "ERROR: Failed to create ext4 on /dev/mapper/$MAPPER_NAME. Aborting."
    exit 1
fi

# 4. Mount the filesystem
echo "Mounting /dev/mapper/$MAPPER_NAME to $MOUNT_POINT..."
if ! mount "/dev/mapper/$MAPPER_NAME" "$MOUNT_POINT"; then
    echo "ERROR: Failed to mount /dev/mapper/$MAPPER_NAME. Aborting."
    exit 1
fi

echo "Ephemeral LUKS scratch partition setup complete for $LUKS_DEV."